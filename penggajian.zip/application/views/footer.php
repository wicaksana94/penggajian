<footer class="footer mt-auto text-center bg-light">
  <div class="container">
    <span class="text-muted">By Arya @ <?php echo date('Y'); ?></span>
  </div>
</footer>
</body>
</html>